"""
models/output_schema.py

Defines the structured data that flows through the pipeline and the final
JSON shape that gets written to disk.

Using dataclasses (instead of raw dicts everywhere) gives us:
- type hints / autocomplete while writing pipeline code
- one obvious place to look at when asking "what does our JSON look like?"
- a single `to_dict()` per class, so serialization logic doesn't leak
  into main.py or the individual pipeline stages.

IMPORTANT: this file describes the CURRENT (screenshot-only) output.
The `solidworks_api_data` field is included but left as `None` / empty by
default - it's a placeholder for the future C# API integration described
in the project brief, so that adding it later doesn't require reshaping
this schema.

SCOPE BOUNDARY - PROBLEM IDENTIFICATION ONLY, NEVER SOLUTIONS:
This entire pipeline (image preprocessing, region detection, OCR, and the
vision-model interface) is responsible for identifying and describing
WHAT is visible and WHAT problem it points to - never HOW to fix it.
There is deliberately no `solution`, `suggested_action`, `fix`,
`recommendation`, or `next_steps` field anywhere in this schema, and none
should be added. Deciding what to do about a detected problem is a job
for a downstream system (or a human), not this pipeline. If you're adding
a field and it describes an action to take rather than something
observed or inferred from the screenshot, it does not belong here.
"""

from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Any, Optional

# Field names that must never appear anywhere in the output JSON. This
# pipeline identifies problems; it does not prescribe fixes. The check in
# `ScreenshotAnalysis.to_dict()` exists as a structural safety net - it
# catches the case where someone extends this schema (or a future
# `VisionModelClient` implementation returns extra keys) and accidentally
# reintroduces solution-oriented output.
FORBIDDEN_FIELD_NAMES = {"solution", "suggested_action", "fix", "recommendation", "next_steps"}


class SolutionFieldNotAllowedError(Exception):
    """Raised if a forbidden solution/fix-style field is found in the output."""


def _assert_no_forbidden_fields(value: Any, path: str = "") -> None:
    """Recursively walk a dict/list structure and raise if any key matches
    a forbidden (solution-oriented) field name, at any nesting depth."""
    if isinstance(value, dict):
        for key, sub_value in value.items():
            if str(key).lower() in FORBIDDEN_FIELD_NAMES:
                location = f"{path}.{key}" if path else str(key)
                raise SolutionFieldNotAllowedError(
                    f"Forbidden field '{location}' found in screenshot-analysis output. "
                    f"This pipeline identifies problems only - it must not include "
                    f"solutions, fixes, or suggested actions."
                )
            _assert_no_forbidden_fields(sub_value, f"{path}.{key}" if path else str(key))
    elif isinstance(value, list):
        for i, item in enumerate(value):
            _assert_no_forbidden_fields(item, f"{path}[{i}]")


@dataclass
class ImageInfo:
    """Basic facts about the screenshot itself."""

    width: int
    height: int
    original_path: str
    was_resized: bool = False

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class BBox:
    """Axis-aligned bounding box in pixel coordinates: (x_min, y_min, x_max, y_max)."""

    x_min: int
    y_min: int
    x_max: int
    y_max: int

    def as_list(self) -> list:
        return [self.x_min, self.y_min, self.x_max, self.y_max]


@dataclass
class Region:
    """A detected region of interest in the SOLIDWORKS UI (e.g. feature tree)."""

    name: str
    bbox: BBox
    confidence: float
    detection_method: str = "heuristic"  # "heuristic" | "vision_model" (future)

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "confidence": round(self.confidence, 3),
            "bbox": self.bbox.as_list(),
            "detection_method": self.detection_method,
        }


@dataclass
class OcrResult:
    """A single piece of OCR-extracted text with its location and confidence."""

    text: str
    confidence: float
    bbox: BBox
    region_name: Optional[str] = None  # which detected Region this text came from, if any

    def to_dict(self) -> dict:
        return {
            "text": self.text,
            "confidence": round(self.confidence, 3),
            "bbox": self.bbox.as_list(),
            "region": self.region_name,
        }


@dataclass
class VisualObservations:
    """
    High-level yes/no-ish flags a troubleshooting system would want to check
    first, before reading the fine-grained region/OCR detail.

    Every flag defaults to False/None - nothing is claimed as present
    unless the pipeline actually detected it.
    """

    error_message_visible: bool = False
    warning_message_visible: bool = False
    feature_tree_visible: bool = False
    property_manager_visible: bool = False
    graphics_area_visible: bool = False
    status_bar_visible: bool = False
    dialog_visible: bool = False

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class VisionAnalysisResult:
    """
    Output of the (currently stubbed) AI/vision analysis stage.
    See vision/analyzer.py for the interface this comes from.

    PROBLEM IDENTIFICATION ONLY: `detected_problem` and `evidence` should
    describe WHAT is wrong (e.g. "Extrude1 has a rebuild error caused by
    a self-intersecting profile") and WHAT was observed to support that
    conclusion - never HOW to fix it. Do not add a solution/fix/
    suggested_action/recommendation field to this class, and do not let
    `detected_problem`/`evidence` text drift into giving instructions.
    """

    detected_problem: Optional[str] = None
    confidence: float = 0.0
    evidence: list[str] = field(default_factory=list)
    model_used: str = "none"  # e.g. "null_stub", "openai:gpt-4o", "anthropic:claude-sonnet"

    def to_dict(self) -> dict:
        return {
            "detected_problem": self.detected_problem,
            "confidence": round(self.confidence, 3),
            "evidence": self.evidence,
            "model_used": self.model_used,
        }


@dataclass
class ScreenshotAnalysis:
    """Top-level container for everything produced by the pipeline."""

    image: ImageInfo
    regions: list[Region] = field(default_factory=list)
    ocr: list[OcrResult] = field(default_factory=list)
    visual_observations: VisualObservations = field(default_factory=VisualObservations)
    vision_analysis: Optional[VisionAnalysisResult] = None

    # Placeholder for the future C# SOLIDWORKS API JSON. Left as None for
    # this Python-only V1; wiring this up later should not require
    # changing anything else in this schema.
    solidworks_api_data: Optional[dict[str, Any]] = None

    def to_dict(self) -> dict:
        result = {
            "image": self.image.to_dict(),
            "regions": [r.to_dict() for r in self.regions],
            "ocr": [o.to_dict() for o in self.ocr],
            "visual_observations": self.visual_observations.to_dict(),
            "vision_analysis": self.vision_analysis.to_dict() if self.vision_analysis else None,
            "solidworks_api_data": self.solidworks_api_data,
        }

        # Structural safety net: this pipeline is problem-identification
        # only. See FORBIDDEN_FIELD_NAMES above. `solidworks_api_data` is
        # deliberately excluded from this check - it's an opaque
        # pass-through of the separate C# application's own JSON, whose
        # schema this project doesn't own or constrain.
        _assert_no_forbidden_fields(
            {k: v for k, v in result.items() if k != "solidworks_api_data"}
        )

        return result
