"""
vision/analyzer.py

Defines the interface a future AI/vision model will implement in order to
turn (screenshot + OCR text + detected regions) into an actual SOLIDWORKS
problem diagnosis.

THIS FILE DOES NOT CALL ANY AI PROVIDER. It exists purely to:
1. Define a clean, stable contract (`VisionModelClient`) that any future
   implementation - OpenAI, Anthropic, a local model, or a rules engine -
   can satisfy.
2. Provide a `NullVisionModel` stub so the rest of the pipeline (main.py)
   can run end-to-end today and produce a valid, well-formed
   `VisionAnalysisResult` even before a real model is plugged in.

WHEN YOU'RE READY TO ADD A REAL MODEL:
Create a new class (e.g. `OpenAIVisionModel` in a new file
`vision/openai_client.py`) that implements `VisionModelClient`, and pass
an instance of it into `analyze_screenshot()` instead of `NullVisionModel`.
Nothing else in this project needs to change.

SCOPE BOUNDARY - PROBLEM IDENTIFICATION ONLY:
Any implementation of `VisionModelClient` must identify and describe the
SOLIDWORKS problem visible in the screenshot - never propose how to fix
it. Prompt any real model accordingly (e.g. "identify the problem and the
visual evidence for it; do not suggest a fix or corrective action") and
keep the returned `VisionAnalysisResult` limited to `detected_problem`,
`confidence`, and `evidence`. Do not add or populate a solution/fix/
suggested_action/recommendation field - `models/output_schema.py`
actively rejects those field names at serialization time. Deciding what
to do about a detected problem is out of scope for this pipeline.
"""

from __future__ import annotations

from typing import Protocol

import numpy as np

from models.output_schema import OcrResult, Region, VisionAnalysisResult


class VisionModelClient(Protocol):
    """
    Contract for any AI/vision backend that can analyze a SOLIDWORKS
    screenshot together with the OCR and region data already extracted.

    A concrete implementation might, for example, send the screenshot
    (optionally with cropped region images) plus the OCR text as a prompt
    to a multimodal LLM and parse its response into a VisionAnalysisResult.
    """

    def analyze(
        self,
        image: np.ndarray,
        ocr_results: list[OcrResult],
        regions: list[Region],
    ) -> VisionAnalysisResult:
        """
        Analyze a screenshot and return a structured diagnosis.

        Args:
            image: the (resized) screenshot as a BGR NumPy array.
            ocr_results: text already extracted by ocr/extractor.py.
            regions: UI regions already detected by image/regions.py.

        Returns:
            A VisionAnalysisResult describing what problem (if any) was
            identified, how confident the model is, and what evidence
            supports that conclusion. Must NOT include a solution, fix,
            or suggested corrective action - identification only.
        """
        ...


class NullVisionModel:
    """
    Placeholder implementation used until a real AI model is connected.

    Rather than guessing at a diagnosis, this stub is explicit about the
    fact that no real analysis has happened yet - it reports zero
    confidence and empty evidence, so downstream consumers of the JSON
    output can clearly tell "no vision analysis was performed" apart from
    "the vision model looked and found nothing".
    """

    def analyze(
        self,
        image: np.ndarray,
        ocr_results: list[OcrResult],
        regions: list[Region],
    ) -> VisionAnalysisResult:
        return VisionAnalysisResult(
            detected_problem=None,
            confidence=0.0,
            evidence=[],
            model_used="none",
        )


def analyze_screenshot(
    image: np.ndarray,
    ocr_data: list[OcrResult],
    regions: list[Region],
    model: VisionModelClient | None = None,
) -> VisionAnalysisResult:
    """
    Run vision/AI analysis on a screenshot using the given model client.

    If no `model` is provided, falls back to `NullVisionModel`, so this
    function - and therefore the whole pipeline in main.py - always
    returns a valid, well-formed result, with or without a real AI model
    plugged in.
    """
    active_model: VisionModelClient = model if model is not None else NullVisionModel()
    return active_model.analyze(image, ocr_data, regions)
