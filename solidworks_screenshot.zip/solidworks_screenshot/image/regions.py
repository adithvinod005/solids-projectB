"""
image/regions.py

Detects likely UI regions within a SOLIDWORKS screenshot: feature tree,
graphics/model area, PropertyManager panel, status bar, and any dialog
box that might be floating on top.

HONESTY ABOUT LIMITATIONS:
SOLIDWORKS' UI layout is customizable (panels can be docked, floated,
resized, or hidden), and we have no access to the application's internal
window layout - only pixels. So this module uses simple, transparent
heuristics:

  1. Position-based defaults, informed by SOLIDWORKS' typical layout
     (tree + PropertyManager on the left, graphics area centered, status
     bar along the bottom).
  2. A cheap visual check (edge density) to distinguish the FeatureManager
     tree/PropertyManager column - which is text/line heavy - from the
     graphics area, which is often visually sparser except when a model
     is loaded.
  3. A simple bright-rectangle check for floating dialog boxes.

None of this is claimed to be highly accurate. Every region gets a
confidence score, and this module is explicitly designed to be
supplemented or replaced later by a real vision model (see
vision/analyzer.py) which can look at the actual pixels and understand
context far better than position heuristics can.
"""

from __future__ import annotations

import cv2
import numpy as np

from config import (
    FEATURE_TREE_X_RATIO,
    FEATURE_TREE_Y_RATIO,
    GRAPHICS_AREA_X_RATIO,
    GRAPHICS_AREA_Y_RATIO,
    HEURISTIC_REGION_CONFIDENCE,
    STATUS_BAR_X_RATIO,
    STATUS_BAR_Y_RATIO,
)
from models.output_schema import BBox, Region


def _ratio_to_bbox(
    width: int, height: int, x_ratio: tuple[float, float], y_ratio: tuple[float, float]
) -> BBox:
    """Convert fractional (0.0-1.0) region boundaries into pixel coordinates."""
    x_min = int(round(x_ratio[0] * width))
    x_max = int(round(x_ratio[1] * width))
    y_min = int(round(y_ratio[0] * height))
    y_max = int(round(y_ratio[1] * height))
    return BBox(x_min=x_min, y_min=y_min, x_max=x_max, y_max=y_max)


def _crop(image: np.ndarray, bbox: BBox) -> np.ndarray:
    return image[bbox.y_min:bbox.y_max, bbox.x_min:bbox.x_max]


def _edge_density(image_region: np.ndarray) -> float:
    """
    Fraction of pixels that are edges (via Canny), used as a cheap proxy for
    "this area contains a lot of text/UI lines" vs. "this area is mostly
    empty/uniform".

    The FeatureManager tree and PropertyManager panels tend to have high
    edge density (many small text rows, icons, indent lines). An empty
    graphics area (no model loaded) tends to have very low edge density.
    """
    if image_region.size == 0:
        return 0.0

    gray = cv2.cvtColor(image_region, cv2.COLOR_BGR2GRAY) if image_region.ndim == 3 else image_region
    edges = cv2.Canny(gray, 50, 150)
    return float(np.count_nonzero(edges)) / float(edges.size)


def detect_feature_tree_region(image: np.ndarray) -> Region:
    """
    Detect the likely FeatureManager tree location.

    Uses the standard left-column position, with confidence adjusted
    upward if that area shows the text-heavy edge pattern typical of a
    tree view, and downward if it looks empty (tree may be hidden/closed).
    """
    height, width = image.shape[:2]
    bbox = _ratio_to_bbox(width, height, FEATURE_TREE_X_RATIO, FEATURE_TREE_Y_RATIO)
    density = _edge_density(_crop(image, bbox))

    confidence = HEURISTIC_REGION_CONFIDENCE
    if density > 0.05:
        confidence = min(0.9, confidence + 0.3)
    elif density < 0.01:
        confidence = max(0.1, confidence - 0.3)

    return Region(name="feature_tree", bbox=bbox, confidence=confidence)


def detect_property_manager_region(image: np.ndarray) -> Region:
    """
    Detect a possible PropertyManager panel.

    The PropertyManager occupies roughly the same screen column as the
    feature tree (it replaces the tree view while a feature/sketch is
    being edited). Since we can't reliably tell these apart from position
    alone, we report this region with a lower baseline confidence -
    a vision model is the appropriate tool for actually disambiguating
    "tree" vs. "PropertyManager" vs. "neither visible".
    """
    height, width = image.shape[:2]
    bbox = _ratio_to_bbox(
        width, height,
        (0.0, 0.18),
        (0.05, 0.95),
    )
    density = _edge_density(_crop(image, bbox))

    # Slightly lower baseline than the tree - this is an ambiguous guess,
    # not a distinct detection signal.
    confidence = HEURISTIC_REGION_CONFIDENCE - 0.15
    if density > 0.05:
        confidence = min(0.6, confidence + 0.2)
    else:
        confidence = max(0.05, confidence - 0.2)

    return Region(name="property_manager", bbox=bbox, confidence=confidence)


def detect_graphics_area_region(image: np.ndarray) -> Region:
    """Detect the main 3D graphics/model viewing area."""
    height, width = image.shape[:2]
    bbox = _ratio_to_bbox(width, height, GRAPHICS_AREA_X_RATIO, GRAPHICS_AREA_Y_RATIO)

    # The graphics area is almost always present in a SOLIDWORKS window,
    # regardless of what's in it, so we give it a reasonably high
    # baseline confidence just for occupying the expected position.
    confidence = 0.7

    return Region(name="graphics_area", bbox=bbox, confidence=confidence)


def detect_status_bar_region(image: np.ndarray) -> Region:
    """Detect the status bar strip along the bottom of the window."""
    height, width = image.shape[:2]
    bbox = _ratio_to_bbox(width, height, STATUS_BAR_X_RATIO, STATUS_BAR_Y_RATIO)
    return Region(name="status_bar", bbox=bbox, confidence=HEURISTIC_REGION_CONFIDENCE)


def detect_dialog_region(image: np.ndarray) -> Region | None:
    """
    Look for a floating modal dialog box (e.g. a "What's Wrong" or rebuild
    error dialog) using a simple heuristic: SOLIDWORKS dialogs are usually
    bright, rectangular, roughly-centered panels with a strong border
    contrast against the rest of the window.

    Returns None if nothing dialog-like is found - this heuristic is
    intentionally conservative to avoid false positives, since claiming a
    dialog is present when it isn't could mislead troubleshooting.
    """
    height, width = image.shape[:2]
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    # Threshold for bright, uniform regions (typical dialog background).
    _, bright_mask = cv2.threshold(gray, 200, 255, cv2.THRESH_BINARY)

    contours, _ = cv2.findContours(bright_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    best_candidate: BBox | None = None
    best_area = 0.0
    image_area = float(width * height)

    for contour in contours:
        x, y, w, h = cv2.boundingRect(contour)
        area = w * h

        # A plausible dialog: not the whole window, not tiny, roughly
        # centered, and not touching all four edges (which would suggest
        # it's just the graphics area background, not a floating box).
        area_ratio = area / image_area
        touches_edges = x <= 2 and y <= 2 and (x + w) >= width - 2 and (y + h) >= height - 2

        if 0.03 < area_ratio < 0.5 and not touches_edges:
            if area > best_area:
                best_area = area
                best_candidate = BBox(x_min=x, y_min=y, x_max=x + w, y_max=y + h)

    if best_candidate is None:
        return None

    # Conservative confidence - this is a rough shape heuristic, easily
    # fooled by a bright empty graphics area or a white sketch plane.
    return Region(name="dialog", bbox=best_candidate, confidence=0.35)


def detect_all_regions(image: np.ndarray) -> list[Region]:
    """
    Run all region detectors and return the results as a single list.

    This is the main entry point other modules (main.py, ocr/extractor.py)
    should call - it hides the fact that each region type has its own
    detection function.
    """
    regions = [
        detect_feature_tree_region(image),
        detect_property_manager_region(image),
        detect_graphics_area_region(image),
        detect_status_bar_region(image),
    ]

    dialog = detect_dialog_region(image)
    if dialog is not None:
        regions.append(dialog)

    return regions
