"""
main.py

CLI entry point for the SOLIDWORKS screenshot-analysis pipeline.

Usage:
    python main.py path/to/screenshot.png
    python main.py path/to/screenshot.png --output path/to/output.json
    python main.py path/to/screenshot.png --no-ocr

This ties together, in order:
    1. image/loader.py         - load & validate the screenshot
    2. image/preprocessing.py  - resize + enhance for OCR
    3. image/regions.py        - detect likely UI regions
    4. ocr/extractor.py        - extract text from those regions
    5. vision/analyzer.py      - (stub) AI/vision analysis hook
    6. models/output_schema.py - assemble everything into JSON

The pipeline is intentionally linear and readable end-to-end from this
one file - if you want to understand what the program does, start here.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import config
from image.loader import ImageLoadError, get_image_dimensions, load_image
from image.preprocessing import preprocess_screenshot
from image.regions import detect_all_regions
from ocr.extractor import extract_text_from_regions, is_ocr_available
from models.output_schema import ImageInfo, OcrResult, Region, ScreenshotAnalysis, VisualObservations
from vision.analyzer import analyze_screenshot


def build_visual_observations(regions: list[Region], ocr_results: list[OcrResult]) -> VisualObservations:
    """
    Derive high-level yes/no observations from the detected regions and OCR
    text. This is where region/OCR confidence gets turned into the simple
    flags a troubleshooting system would check first.

    A region "counts" as visible if its detection confidence clears a
    modest bar - low-confidence heuristic guesses shouldn't be reported as
    confirmed facts.
    """
    VISIBILITY_THRESHOLD = 0.5

    def region_visible(name: str) -> bool:
        return any(r.name == name and r.confidence >= VISIBILITY_THRESHOLD for r in regions)

    ocr_text_lower = " ".join(o.text.lower() for o in ocr_results)
    error_keyword_hit = any(keyword in ocr_text_lower for keyword in config.ERROR_KEYWORDS)

    return VisualObservations(
        error_message_visible=error_keyword_hit and "error" in ocr_text_lower,
        warning_message_visible=error_keyword_hit and "warning" in ocr_text_lower,
        feature_tree_visible=region_visible("feature_tree"),
        property_manager_visible=region_visible("property_manager"),
        graphics_area_visible=region_visible("graphics_area"),
        status_bar_visible=region_visible("status_bar"),
        dialog_visible=region_visible("dialog"),
    )


def run_pipeline(image_path: str, run_ocr: bool = True) -> ScreenshotAnalysis:
    """
    Run the full screenshot-analysis pipeline on a single image file and
    return the resulting ScreenshotAnalysis object.

    Raises ImageLoadError if the file can't be loaded - callers (like
    `main()`) are expected to catch this and present a clean error message.
    """
    raw_image = load_image(image_path)
    preprocessed = preprocess_screenshot(raw_image)
    resized_image = preprocessed["resized"]
    ocr_ready_image = preprocessed["ocr_ready"]

    width, height = get_image_dimensions(resized_image)
    image_info = ImageInfo(
        width=width,
        height=height,
        original_path=str(Path(image_path).resolve()),
        was_resized=preprocessed["was_resized"],
    )

    regions = detect_all_regions(resized_image)

    ocr_results: list[OcrResult] = []
    if run_ocr:
        ocr_results = extract_text_from_regions(ocr_ready_image, regions)

    visual_observations = build_visual_observations(regions, ocr_results)

    # Vision/AI analysis stage - currently a stub (see vision/analyzer.py).
    # Wired in here so the JSON output always has the field, ready for a
    # real model to be plugged in later without changing this pipeline.
    vision_result = analyze_screenshot(resized_image, ocr_results, regions)

    return ScreenshotAnalysis(
        image=image_info,
        regions=regions,
        ocr=ocr_results,
        visual_observations=visual_observations,
        vision_analysis=vision_result,
    )


def print_summary(analysis: ScreenshotAnalysis, ocr_ran: bool) -> None:
    """Print a short, human-readable summary of what was detected."""
    print("\n--- Screenshot Analysis Summary ---")
    print(f"Image size: {analysis.image.width}x{analysis.image.height}"
          f"{' (resized)' if analysis.image.was_resized else ''}")

    print("\nDetected regions:")
    for region in analysis.regions:
        print(f"  - {region.name:<18} confidence={region.confidence:.2f}  bbox={region.bbox.as_list()}")

    if not ocr_ran:
        print("\nOCR: skipped (--no-ocr)")
    elif not is_ocr_available():
        print("\nOCR: unavailable (Tesseract not found - see README for install instructions)")
    elif not analysis.ocr:
        print("\nOCR: ran, but no text met the confidence threshold")
    else:
        print(f"\nOCR text found ({len(analysis.ocr)} items):")
        for item in analysis.ocr:
            preview = item.text if len(item.text) <= 60 else item.text[:57] + "..."
            print(f"  - [{item.region_name or 'full image'}] \"{preview}\" (confidence={item.confidence:.0f})")

    print("\nVisual observations:")
    for key, value in analysis.visual_observations.to_dict().items():
        print(f"  - {key}: {value}")

    print("\nVision/AI analysis: (stub - no model connected yet)")
    print(f"  - detected_problem: {analysis.vision_analysis.detected_problem}")
    print("------------------------------------\n")


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Analyze a SOLIDWORKS screenshot and produce structured JSON output."
    )
    parser.add_argument("screenshot", help="Path to the SOLIDWORKS screenshot image.")
    parser.add_argument(
        "--output",
        default=None,
        help=f"Path to write the JSON output to. Defaults to "
             f"{config.OUTPUT_DIR / config.DEFAULT_OUTPUT_FILENAME}",
    )
    parser.add_argument(
        "--no-ocr",
        action="store_true",
        help="Skip OCR text extraction (useful if Tesseract isn't installed).",
    )
    args = parser.parse_args()

    try:
        analysis = run_pipeline(args.screenshot, run_ocr=not args.no_ocr)
    except ImageLoadError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1

    output_path = Path(args.output) if args.output else config.OUTPUT_DIR / config.DEFAULT_OUTPUT_FILENAME
    output_path.parent.mkdir(parents=True, exist_ok=True)

    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(analysis.to_dict(), f, indent=2)

    print_summary(analysis, ocr_ran=not args.no_ocr)
    print(f"Full JSON output written to: {output_path.resolve()}")

    return 0


if __name__ == "__main__":
    sys.exit(main())
